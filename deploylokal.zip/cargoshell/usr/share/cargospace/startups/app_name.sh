#!/bin/sh

# load user provided environment variable first, so we can overite bad onces.

export PORT="8000"
# Call node directly or use forever
# Also ensure that this script has a 755 permission
# /usr/bin/nodejs /usr/lib/atomiadns/webapp/atomiadns.js

# systemctl enable nodejs-APP_NAME.service
# systemctl start nodejs-APP_NAME.service