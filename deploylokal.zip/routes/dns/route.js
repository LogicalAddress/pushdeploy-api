var NameServer = require('../../lib/dns/lib.js');
var _ = require('underscore');
var checkCreateZone = require("../../validation/dns/CreateZone");
var checkImportZone = require("../../validation/dns/ImportZone");
var checkEditZoneEntry = require("../../validation/dns/EditZoneEntry");
var checkAddZoneEntry = require("../../validation/dns/AddZoneEntry");

	/*
	* NAME SERVERS with atomiadns
	*/
	
	
module.exports = function (app) {

	/*
	* All DNS Root zone (Admin)
	*/
	
	app.get('/v1/dns/zone', (req, res, next) => {
		NameServer.getAllZones().then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Get zone info (Admin)
	*/
	
	app.get('/v1/dns/zone/:zone', (req, res, next) => {
		NameServer.getZone(req.params.zone).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Creat a new zone (Admin)
	*/
	
	app.post('/v1/dns/zone', checkCreateZone, (req, res, next) => {
		NameServer.AddZone(req.body).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Delete zone (Admin)
	*/
	
	app.delete('/v1/dns/zone/:zone', (req, res, next) => {
		NameServer.DeleteZone(req.params.zone).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Export zone (Admin)
	*/
	
	app.get('/v1/dns/zone/export/:zone', (req, res, next) => {
		NameServer.GetZoneBinary(req.params.zone).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Import zone (Admin)
	*/
	
	app.post('/v1/dns/zone/import', checkImportZone, (req, res, next) => {
		NameServer.RestoreZoneBinary(req.body).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Delete a DNS record (Admin)
	*/
	
	app.delete('/v1/dns/zone/:zone/:id', (req, res, next) => {
		NameServer.DeleteDnsRecord({
			name: req.params.zone,
			id: req.params.id
		}).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Edit a DNS record of a zone (Admin)
	*/
	
	app.put('/v1/dns/zone/:zone/:id', checkEditZoneEntry, (req, res, next) => {
		NameServer.EditDnsRecord(req.body).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	/*
	* Add a single DNS record to a zone (Admin)
	*/
	
	app.post('/v1/dns/zone/:zone', checkAddZoneEntry, (req, res, next) => {
		NameServer.AddDnsRecord(req.body).then((result)=>{
    		res.status(200).json(result);
    	}).catch((error)=>{
    		res.status(500).json(error);
    	});
	});
	
	
	/*
	* User Owned Root zone
	*/
	
	app.get('/v1/dns/user/zone', (req, res, next) => {
		res.status(200).json({});
	});
	
	/*
	* Create Zone
	*/
	
	app.post('/v1/dns/user/zone', (req, res, next) => {
		res.status(200).json({});
	});
	
	/*
	*  Update Zone
	*/
	
	app.put('/v1/dns/user/zone/:id', (req, res, next) => {
		res.status(200).json({});
	});
	
	
	/*
	* Delete Zone
	*/
	
	app.delete('/v1/dns/user/zone/:id', (req, res, next) => {
		res.status(200).json({});
	});
};