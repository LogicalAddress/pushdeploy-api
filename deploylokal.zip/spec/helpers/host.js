var config = require('../../config/app');
module.exports = function(){
	return config.AppDomain;
};