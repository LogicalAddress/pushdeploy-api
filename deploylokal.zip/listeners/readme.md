# IMPORTANT 

UPGRADING API VERSION IS THE SAME AS UPGRADING CARGOSHELL VERSION (from v1 to v2),

All implementation in the new release (v2) must implement new listeners and triger different events depending on what changed

